
package javagraphics;

import java.awt.*;  
import java.awt.geom.*;
import javax.swing.JPanel;

/*******************************************************************************
 * 2) Define the Panel Class: "DrawCanvas", extends JPanel
 ******************************************************************************/
class DrawCanvas extends JPanel {
    //2.0) Setup canvas parameters, width, height, color
    static final int CANVAS_WIDTH = 1400;
    static final int CANVAS_HEIGHT = 800;
    static Color CANVAS_BG_COLOR = Color.CYAN;
    
    //2.1) define variables
    int moveStep = 2;
    int moveDir = 1;
    Sprite target;     // the moving object
    //Sprite missile;  // the moving object
    //--------------------------------------------------------
    // 2.2) Constructor of DrawCanvas
    //--------------------------------------------------------
    public DrawCanvas() {
        setPreferredSize(new Dimension(CANVAS_WIDTH, CANVAS_HEIGHT));
  
        // Construct a sprite given x, y, width, height, color
        int X0 = CANVAS_WIDTH / 2 - 10;
        int Y0 = CANVAS_HEIGHT / 2 - 10;
        target = new Sprite(X0, Y0,20, 20, Color.RED);
        
        //missile = new Sprite(100, 20, 20, 20, Color.BLACK); // to test repaint
    }
    
    //--------------------------------------------------------
    // 2.3) Define moving methods
    //--------------------------------------------------------
    public void moveAround()    {
        boolean moveOK;
        if(moveDir > 0)    {
            moveOK = moveRight();
            if(moveOK == false)
                moveDir = -1;
        }
        else    {
            moveOK = moveLeft();
            if(moveOK == false)
                moveDir = 1;        
        }
    }
    
    public boolean moveLeft() {
        boolean moveOK = true;
        Rectangle rect = target.moveObj(-moveStep, -moveStep);
        // Repaint only the affected areas, not the entire JFrame, for efficiency
        if(canMove(rect))
            repaint(rect);
        else
            moveOK = false; 
        
        return moveOK;
   }
 
    public boolean moveRight() {
        boolean moveOK = true;
        Rectangle rect = target.moveObj(moveStep, moveStep);
        // Repaint only the affected areas, not the entire JFrame, for efficiency
        if(canMove(rect))
            repaint(rect);
        else
            moveOK = false; 
        
        return moveOK;
    }
    
    public void moveUp() {
        Rectangle rect = target.moveObj(0, -moveStep);
        // Repaint only the affected areas, not the entire JFrame, for efficiency
        if(canMove(rect))
            repaint(rect);
   }
 
    public void moveDown() {
        Rectangle rect = target.moveObj(0, moveStep);
        // Repaint only the affected areas, not the entire JFrame, for efficiency
        repaint(rect);
   }

    boolean canMove(Rectangle rect)     {
        Rectangle localRect = new Rectangle(rect.x, rect.y, rect.width, rect.height);
        localRect.x += (moveDir * moveStep);
        localRect.y += (moveDir * moveStep);
        Area area = new Area(new Rectangle(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT));

        return (rect != null && area.contains(localRect));
    }    
    
    //--------------------------------------------------------
    // 2.4) the Painting method, called by JPanel
    //--------------------------------------------------------    
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        setBackground(CANVAS_BG_COLOR);
        
        target.paint(g);  // the sprite paints itself
        //missile.paint(g);  // the sprite paints itself
    }
}
